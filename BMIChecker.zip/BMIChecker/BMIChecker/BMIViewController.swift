//
//  BMIViewController.swift
//  BMIChecker
//
//  Created by Jinne,Swarupa on 11/2/23.
//

import UIKit

class BMIViewController: UIViewController {
    
    @IBOutlet weak var BMIlbOL: UILabel!
    
    @IBOutlet weak var BMIweightOL: UILabel!
    
    @IBOutlet weak var BMIOL: UILabel!
    
    
    @IBOutlet weak var ImageOL: UIImageView!
    
    
    var bmilb = ""
    var bmiheight = ""
    var bmi = 0.0
    var image = ""
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        BMIlbOL.text! += bmilb
        BMIweightOL.text! += bmiheight
        BMIOL.text! += String(bmi)
        ImageOL.image = UIImage(named: image)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
