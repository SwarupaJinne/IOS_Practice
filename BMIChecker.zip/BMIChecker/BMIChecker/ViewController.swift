//
//  ViewController.swift
//  BMIChecker
//
//  Created by Jinne,Swarupa on 11/2/23.
//

import UIKit

class ViewController: UIViewController {
    var TotalBMI = 0.0
    var imageName = ""
    
    @IBOutlet weak var lbOL: UILabel!
    
    

    @IBOutlet weak var heightOL: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calcBtn(_ sender: UIButton) {
        var weight = Double(lbOL.text!) ?? 0.0
        var height = Double(heightOL.text!) ?? 0.0
        TotalBMI = (weight / (height * height)) * 703
        if (TotalBMI <= 18.4){
            imageName = "unweight"
            
        }
        else if (TotalBMI>18.5 || TotalBMI<24.9){
            imageName = "normal"
        }
        else if (TotalBMI>25.0 || TotalBMI<39.9){
            imageName = "0VERWEIGHT"
        }
        else{
            imageName = "obesee"
            
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "BMIsegue"{
            var destination = segue.destination as! BMIViewController
            destination.bmilb = lbOL.text!
            destination.bmiheight = heightOL.text!
            destination.bmi = TotalBMI
            destination.image = imageName
            
        }
    }


}

