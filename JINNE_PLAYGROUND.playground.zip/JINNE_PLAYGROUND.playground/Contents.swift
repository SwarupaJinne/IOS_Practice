import UIKit

var greeting = "Hello, playground"
print("hello, world")
