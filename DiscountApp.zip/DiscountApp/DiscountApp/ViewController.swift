//
//  ViewController.swift
//  DiscountApp
//
//  Created by Jinne,Swarupa on 10/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var AmountOutlet: UITextField!
    
    @IBOutlet weak var DiscountRateOutlet: UITextField!
    var amountAfterDiscount = 0.0
    var imageName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func CalculateBtn(_ sender: UIButton) {
        var amount = Double(AmountOutlet.text!) ?? 0.0
        var discountrate = Double(DiscountRateOutlet.text!) ?? 0.0
        amountAfterDiscount = amount-(amount*discountrate/100)
        
        if (discountrate > 0.0){
            imageName = "dis"
            
        }
        else{
            imageName = "nodis"
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.amountRes = AmountOutlet.text!
            destination.discRes = DiscountRateOutlet.text!
            destination.PriceAfterDesc = amountAfterDiscount
            destination.image = imageName
            
            
        }
        
    }
    

}

