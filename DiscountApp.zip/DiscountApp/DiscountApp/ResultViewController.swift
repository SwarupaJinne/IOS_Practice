//
//  ResultViewController.swift
//  DiscountApp
//
//  Created by Jinne,Swarupa on 10/31/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var AmountResOL: UILabel!
    
    
    @IBOutlet weak var DiscountRateResOL: UILabel!
    
    @IBOutlet weak var AfterDiscountResOL: UILabel!
    
    
    var amountRes = ""
    var discRes = ""
    var PriceAfterDesc = 0.0
    var image = ""
    
    @IBOutlet weak var ImageVieOL: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        AmountResOL.text! += amountRes
        DiscountRateResOL.text! += discRes
        AfterDiscountResOL.text! += String(PriceAfterDesc)
        ImageVieOL.image = UIImage(named: image)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
