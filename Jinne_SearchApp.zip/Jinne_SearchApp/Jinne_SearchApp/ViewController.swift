//
//  ViewController.swift
//  Jinne_SearchApp
//
//  Created by SwarupaJinne on 10/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchBtnOutlet: UIButton!
    
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var PrevOutlet: UIButton!
    
    @IBOutlet weak var resetOutlet: UIButton!
    
    
    @IBOutlet weak var nextOutlet: UIButton!
    
    var Topics = 0
    var turn = 0
    let arr = [["maheshbabu","surya","nani","ntr","karthi"],["rose","jasmine","Lilly","sunflower","tulip"],["parrot","peacock","pigeon","sparrow","hummingbird"]]
    let heros_keywords = ["hero","heros","stars"]
    let flowers_keywords = ["flower","flowers","nature"]
    let birds_keywords = ["bird","birds","parrot"]
    let topics_array = [["maheshbabu","surya","nani","ntr","karthi"],["rose","jasmine","Lilly","sunflower","tulip"],["parrot","peacock","pigeon","sparrow","hummingbird"]]


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultImage.image = UIImage(named: "welcome")
        self.topicInfoText.text = "rescvtyhjbtrghyrfvyujhbfdthy"
        //topicInfoText.text! = topics_array[0][0]
        nextOutlet.isHidden = true
        resetOutlet.isHidden = true
        PrevOutlet.isHidden = true
        searchBtnOutlet.isEnabled = false
    }
    
    @IBAction func searchFieldBtn(_ sender: UITextField) {
        searchBtnOutlet.isEnabled = true
    }
    
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        nextOutlet.isHidden = false
        resetOutlet.isHidden = false
        PrevOutlet.isHidden = false
        PrevOutlet.isEnabled = false
        let temp = searchTextField.text!
        if(heros_keywords.contains(temp)){
            resultImage.image = UIImage(named: arr[0][0])
            topicInfoText.text = topics_array[0][0]
            Topics = 1
        }
        else if(flowers_keywords.contains(temp)){
            resultImage.image = UIImage(named: arr[1][0])
            topicInfoText.text = topics_array[1][0]
            Topics = 2
        }
        else if(birds_keywords.contains(temp)){
            resultImage.image = UIImage(named: arr[2][0])
            topicInfoText.text = topics_array[2][0]
            Topics = 3
        }
        else{
            resultImage.image = UIImage(named: "notfound")
            searchTextField.text = ""
            topicInfoText.text = ""
            nextOutlet.isHidden = true
            resetOutlet.isHidden = true
            PrevOutlet.isHidden = true
        }
    }
    
    
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        turn = turn-1
        if Topics == 1{
            resultImage.image = UIImage(named: arr[0][turn])
            topicInfoText.text = topics_array[0][turn]

        }
        else if
            Topics == 2{
            resultImage.image = UIImage(named: arr[1][turn])
            topicInfoText.text = topics_array[1][turn]

        }
        else if
            Topics == 3{
            resultImage.image = UIImage(named: arr[2][turn])
            topicInfoText.text = topics_array[2][turn]

        }
        nextOutlet.isEnabled = true
        if turn == 0{
            PrevOutlet.isEnabled = false
        }
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.text = ""
        searchTextField.text = ""
        PrevOutlet.isHidden = true
        resetOutlet.isHidden = true
        nextOutlet.isHidden = true
        searchBtnOutlet.isEnabled = false
    }
    
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        turn = turn+1
        
        if Topics == 1{
            resultImage.image = UIImage(named: arr[0][turn])
            topicInfoText.text = topics_array[0][turn]

        }
        else if
            Topics == 2{
            resultImage.image = UIImage(named: arr[1][turn])
            topicInfoText.text = topics_array[1][turn]

        }
        else if
            Topics == 3{
            resultImage.image = UIImage(named: arr[2][turn])
            topicInfoText.text = topics_array[2][turn]

        }
        PrevOutlet.isEnabled = true
        
        if turn == arr[0].count-1 || turn == arr[1].count-1 || turn == arr[2].count-1 {
            nextOutlet.isEnabled = false
        }
    
    }
    


}

