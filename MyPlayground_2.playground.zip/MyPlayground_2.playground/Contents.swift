import UIKit

var greeting = "Hello, playground"
print("HELLO WORLD!")
print("hello", 11, 11.1, "nwmsu", 11.111)
var message = "This is the basic programming"
print(greeting + message)
print("This is the second cls of ios \(message)")
var age = 4;
print("my age is \(age)")
//print("my age is" + age)
print("my age is: \(age) ane my mon is triple of mine i.e \(age * 3)")
print("""
ios
ios
ios
""")
//carrier return
print("hi , \r welcome to ios class")
//let is a constant

let name = "mellissa"
print(name, "john")
print("bla bla bla")
print("lol lol lol")
print("welcome to ios class", terminator: " second day")
print("hiiiii")

print(1,2,3,4,5,6, separator: "_______")

var namee = "mimi"
print(namee)
print("namee")

let pi = 3.14
print(pi)


//explicit declaration
var agee : Int = 23
age = agee*5
print(agee)

var term = "spring"
term = "fall"
print(term)

var c1 = "hiiiii"
var c2 = "helloooo"
print(c1,c2)
print(c1,"------",c2)


print(1,1,1,1)
print(11.1,1.1,111.1,1111.1)
print("hi", 1, 3, "😊")

var httperror = (errorcode: 404, errormessage: "page not found")
print(httperror)
print(httperror.errorcode, terminator: ",")
print(httperror.errormessage)


var nameee = ("Joh", "smith")
var fname = nameee.0
var lname = nameee.1
print(fname.count)
print(lname.count)
print(fname, terminator: ",")
print(lname)


var origin = (x:0, y:0)
var point = origin
print(point)

let city = (name: "maryville", poulation : 12341)
let (cityname, citypopulation) = (city.0, city.1)
print(cityname)
print(citypopulation)

let groceries = ("bread", "onions" , 1, 2, 1.11, "😊")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))
var fnameeee = "joeee"
var lnameee = "root"
(fnameeee,lnameee) = (lnameee,fnameeee)
print(fnameeee,lnameee)

var cricketkit = ("handgloves", "helmet", ("bat","ball"))
print(cricketkit.0)
print(cricketkit.1)
print(cricketkit.2.0)
print(cricketkit.2.1
)
      

