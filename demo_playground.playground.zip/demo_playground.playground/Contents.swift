import UIKit

var greeting = "Hello, playground"
print("abcdef")
print("masters")
print("computer_science")
print("sios")

