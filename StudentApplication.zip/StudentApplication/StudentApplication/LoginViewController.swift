//
//  ViewController.swift
//  StudentApplication
//
//  Created by Jinne,Swarupa on 11/7/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var SidOL: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func StudentDetailsBtn(_ sender: UIButton) {
    }
    
    


}

