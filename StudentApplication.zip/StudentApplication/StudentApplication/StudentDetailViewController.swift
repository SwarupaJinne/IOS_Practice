//
//  StudentDetailViewController.swift
//  StudentApplication
//
//  Created by Jinne,Swarupa on 11/7/23.
//

import UIKit

class StudentDetailViewController: UIViewController {
    
    
    @IBOutlet weak var Label1OL: UILabel!
    
    
    @IBOutlet weak var Label2OL: UILabel!
    
    
    @IBOutlet weak var Label3OL: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func ViewCoursesBtn(_ sender: UIButton) {
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
